(***********************************************************************)
(*                                                                     *)
(*                           Objective Caml                            *)
(*                                                                     *)
(*            Xavier Leroy, projet Cristal, INRIA Rocquencourt         *)
(*                                                                     *)
(*  Copyright 2002 Institut National de Recherche en Informatique et   *)
(*  en Automatique.  All rights reserved.  This file is distributed    *)
(*  under the terms of the Q Public License version 1.0.               *)
(*                                                                     *)
(***********************************************************************)

(* $Id: optcompile.ml,v 1.43 2002/04/18 07:27:39 garrigue Exp $ *)

(* The batch compiler *)

open Misc
open Config
open Format
open Typedtree

(* Initialize the search path.
   The current directory is always searched first,
   then the directories specified with the -I option (in command-line order),
   then the standard library directory. *)

let init_path () =
  let dirs =
    if !Clflags.thread_safe
    then "+threads" :: !Clflags.include_dirs
    else !Clflags.include_dirs in
  let exp_dirs =
    List.map (expand_directory Config.standard_library) dirs in
  load_path := "" :: List.rev_append exp_dirs (Clflags.std_include_dir ());
  Env.reset_cache()

(* Return the initial environment in which compilation proceeds. *)

let initial_env () =
  init_path();
  try
    if !Clflags.nopervasives
    then Env.initial
    else Env.open_pers_signature "Pervasives" Env.initial
  with Not_found ->
    fatal_error "cannot open Pervasives.cmi"

(* Compile a .mli file *)

let input_lambda = ref false  
let output_lambda = ref false

  
module ObscurLambda = struct
    open Lambda
    
    let find_fv fvs id =
      try
        List.assoc id fvs
      with _ -> id
    
    let make_id fvs id = 
      if not (Ident.persistent id) then
        let new_id = Ident.create "x" in
        fvs := (id, new_id) :: !fvs;
        new_id
      else
        id
    
    let rec shorten_lambda fvs l = 
      match l with
        Lvar id -> Lvar (find_fv fvs id)
      | Lapply (l1, list) -> 
          Lapply (shorten_lambda fvs l1, 
            List.map (shorten_lambda fvs) list)
      | Lfunction (kind, ids, l1) -> 
          let fvs = ref fvs in
          let ids = List.map (make_id fvs) ids in
          Lfunction (kind, ids, shorten_lambda !fvs l1)
      | Llet (kind, id, l1, l2) ->
          let old_fvs = fvs in
          let fvs = ref fvs in
          let id = make_id fvs id in
          Llet(kind, id, shorten_lambda old_fvs l1, 
            shorten_lambda !fvs l2)
      | Lletrec (idls, l1) -> 
          let fvs = ref fvs in
          let idls = List.map (fun (id, l) ->
                make_id fvs id, l) idls in
          let idls = List.map (fun (id, l) ->
                id, shorten_lambda !fvs l) idls in
          Lletrec (idls, shorten_lambda !fvs l1)
      | Lprim (prim, list) ->
          Lprim (prim, List.map (shorten_lambda fvs) list)
      
      | Lswitch (l1, sw) -> (* sw contains lambdas *)
          Lswitch (shorten_lambda fvs l1, 
            { sw_numconsts = sw.sw_numconsts;
              sw_consts = List.map (fun (n,l) -> n
                    , shorten_lambda fvs l) sw.sw_consts;
              sw_numblocks = sw.sw_numblocks;
              sw_blocks = List.map (fun (n,l) -> n
                    , shorten_lambda fvs l) sw.sw_blocks;
              sw_failaction = match sw.sw_failaction with
                None -> None
              | Some l -> Some (shorten_lambda fvs l);
            })
      | Lstaticraise (n, list) ->
          Lstaticraise (n, List.map (shorten_lambda fvs) list)
      | Lstaticcatch (l1, (n,ids), l2) ->
          let old_fvs = fvs in
          let fvs = ref fvs in
          let ids = List.map (make_id fvs) ids in
          Lstaticcatch(shorten_lambda old_fvs l1,
            (n, ids), shorten_lambda !fvs l2)
      | Ltrywith (l1, id, l2) ->
          let old_fvs = fvs in
          let fvs = ref fvs in
          let id = make_id fvs id in
          Ltrywith (shorten_lambda old_fvs l1, id, shorten_lambda !fvs l2)
      | Lifthenelse (l1, l2, l3) ->
          Lifthenelse(shorten_lambda fvs l1, shorten_lambda fvs l2,
            shorten_lambda fvs l3)
      | Lsequence (l1, l2) ->
          Lsequence (shorten_lambda fvs l1, shorten_lambda fvs l2)
      | Lwhile (l1, l2) ->
          Lwhile (shorten_lambda fvs l1, shorten_lambda fvs l2)
      | Lfor (id, l1, l2, dir, l3) ->
          let old_fvs = fvs in
          let fvs = ref fvs in
          let id = make_id fvs id in
          Lfor(id, shorten_lambda old_fvs l1, shorten_lambda old_fvs l2,
            dir, shorten_lambda !fvs l3)
      | Lassign (id, l1) ->
          Lassign(find_fv fvs id, shorten_lambda fvs l1)
      | Lsend (l1, l2, list) ->
          Lsend(shorten_lambda fvs l1, shorten_lambda fvs l2, 
            List.map (shorten_lambda fvs) list)
      | Levent (l1, event) ->
          Levent(shorten_lambda fvs l1, event)
      | Lifused (id, l1) ->
          Lifused (find_fv fvs id, shorten_lambda fvs l1)
      | _ -> l
          
  end
  
let  save_lambda prefixname (n,l) =
  if !output_lambda then begin
      let oc = open_out_bin (prefixname ^ ".lam") in
      let l = ObscurLambda.shorten_lambda [] l in
      output_value oc (n,l, Env.imported_units());
      close_out oc
    end;
  (n,l)

  
let interface ppf sourcefile =
  let prefixname = Misc.chop_extension_if_any sourcefile in
  let modulename = String.capitalize(Filename.basename prefixname) in
  let inputfile = Pparse.preprocess sourcefile in
  try
    let ast =
      Pparse.file ppf inputfile Parse.interface ast_intf_magic_number in
    if !Clflags.dump_parsetree then fprintf ppf "%a@." Printast.interface ast;
    let sg = Typemod.transl_signature (initial_env()) ast in
    if !Clflags.print_types then
      fprintf std_formatter "%a@." Printtyp.signature
                                   (Typemod.simplify_signature sg);
    Warnings.check_fatal ();
    Env.save_signature sg modulename (prefixname ^ ".cmi");
    Pparse.remove_preprocessed inputfile
  with e ->
    Pparse.remove_preprocessed_if_ast inputfile;
    raise e

(* Compile a .ml file *)

let print_if ppf flag printer arg =
  if !flag then fprintf ppf "%a@." printer arg;
  arg
  
let (++) x f = f x
let (+++) (x, y) f = (x, f y)

let implementation ppf sourcefile =
  let prefixname = Misc.chop_extension_if_any sourcefile in
  let modulename = String.capitalize(Filename.basename prefixname) in
  if !input_lambda then
    let ic = open_in_bin (prefixname ^ ".lam") in
    let (n,lam,units) = input_value ic in
    close_in ic;
    let env = initial_env() in
    Compilenv.reset modulename;
    (n,lam) 
    +++ print_if ppf Clflags.dump_lambda Printlambda.lambda
    ++ Asmgen.compile_implementation prefixname ppf ;
    Compilenv.save_unit_info (prefixname ^ ".cmx") units;
    Warnings.check_fatal ();
    
  else
  let inputfile = Pparse.preprocess sourcefile in
  let env = initial_env() in
  Compilenv.reset modulename;
  try
    Pparse.file ppf inputfile Parse.implementation ast_impl_magic_number
    ++ print_if ppf Clflags.dump_parsetree Printast.implementation
    ++ Typemod.type_implementation sourcefile prefixname modulename env
    ++ Translmod.transl_store_implementation modulename
    +++ print_if ppf Clflags.dump_rawlambda Printlambda.lambda
    +++ Simplif.simplify_lambda
    +++ print_if ppf Clflags.dump_lambda Printlambda.lambda
    ++ save_lambda prefixname
    ++ Asmgen.compile_implementation prefixname ppf;
    Compilenv.save_unit_info (prefixname ^ ".cmx") (Env.imported_units());
    Warnings.check_fatal ();
    Pparse.remove_preprocessed inputfile
  with x ->
    Pparse.remove_preprocessed_if_ast inputfile;
    raise x

let c_file name =
  if Ccomp.compile_file name <> 0 then exit 2
